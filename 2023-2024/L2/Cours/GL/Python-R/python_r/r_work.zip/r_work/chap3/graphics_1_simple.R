flowers <- read.table(file = 'data/flower.txt', 
                      header = TRUE, sep = "\t", 
                      stringsAsFactors = TRUE)

##----------------------- Scatterplots ------------------------

plot(flowers$weight)
## See plot in panel

with(flowers, plot(weight)) 

plot(x = flowers$weight, y = flowers$shootarea)
plot(flowers$shootarea ~ flowers$weight)

my_x <- 1:10
my_y <- seq(from = 1, to = 20, by = 2)

par(mfrow = c(2, 2))
plot(my_x, my_y, type = "l")
plot(my_x, my_y, type = "b")
plot(my_x, my_y, type = "o")
plot(my_x, my_y, type = "c")
# p,h, s,n

##----------------------- Histograms ------------------------
par(mfrow = c(1, 1))
hist(flowers$height)

brk <- seq(from = 0, to = 18, by = 1)
hist(flowers$height, breaks = brk, main = "petunia height")

brk <- seq(from = 0, to = 18, by = 1)
hist(flowers$height, breaks = brk, main = "petunia height",freq = FALSE)


dens <- density(flowers$height)
hist(flowers$height, breaks = brk, main = "petunia height",
     freq = FALSE)
lines(dens)

##----------------------- Box and violin plots------------------------

boxplot(flowers$weight, ylab = "weight (g)")

boxplot(weight ~ nitrogen, data = flowers, 
        ylab = "weight (g)", xlab = "nitrogen level")

library(vioplot)
vioplot(weight ~ nitrogen, data = flowers, 
        ylab = "weight (g)", xlab = "nitrogen level",
        col = "lightblue")


##----------------------- Lattice plots------------------------

library(lattice)
histogram(~ height, type = "count", data = flowers)

bwplot(weight ~ nitrogen, data = flowers)

histogram(~ height | nitrogen, type = "count", data = flowers)
histogram(~ height | nitrogen, type = "count",layout = c(1, 3), data = flowers)
histogram(~ height | nitrogen, type = "count",layout = c(3, 1), data = flowers)
