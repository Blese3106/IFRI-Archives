my_vec <- c(2, 3, 1, 6, 4, 3, 3, 7)
my_vec
## [1] 2 3 1 6 4 3 3 7


mean(my_vec)    # returns the mean of my_vec
## [1] 3.625
var(my_vec)     # returns the variance of my_vec
## [1] 3.982143
sd(my_vec)      # returns the standard deviation of my_vec
## [1] 1.995531
length(my_vec)  # returns the number of elements in my_vec
## [1] 8


vec_mean <- mean(my_vec)    # returns the mean of my_vec
vec_mean
## [1] 3.625


my_seq <- 1:10     # create regular sequence
my_seq
##  [1]  1  2  3  4  5  6  7  8  9 10
my_seq2 <- 10:1    # in decending order
my_seq2
##  [1] 10  9  8  7  6  5  4  3  2  1


my_seq2 <- seq(from = 1, to = 5, by = 0.5)
my_seq2
## [1] 1.0 1.5 2.0 2.5 3.0 3.5 4.0 4.5 5.0
my_seq3 <- rep(2, times = 10)   # repeats 2, 10 times
my_seq3
##  [1] 2 2 2 2 2 2 2 2 2 2
my_seq4 <- rep("abc", times = 3)    # repeats ‘abc’ 3 times 
my_seq4
## [1] "abc" "abc" "abc"
my_seq5 <- rep(1:5, times = 3)  # repeats the series 1 to 5, 3 times
my_seq5
##  [1] 1 2 3 4 5 1 2 3 4 5 1 2 3 4 5
my_seq6 <- rep(1:5, each = 3)   # repeats each element of the 
#series 3 times
my_seq6
##  [1] 1 1 1 2 2 2 3 3 3 4 4 4 5 5 5
my_seq7 <- rep(c(3, 1, 10, 7), each = 3) # repeats each element of the series 3 times
my_seq7
##  [1]  3  3  3  1  1  1 10 10 10  7  7  7

