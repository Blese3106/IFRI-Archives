num <- 2.2
class(num)
## [1] "numeric"
char <- "hello"
class(char)
## [1] "character"
logi <- TRUE
class(logi)
## [1] "logical"


is.numeric(num)
## [1] TRUE
is.character(num)
## [1] FALSE
is.character(char)
## [1] TRUE
is.logical(logi)
## [1] TRUE


# coerce numeric to character
class(num)
## [1] "numeric"
num_char <-  as.character(num)
num_char
## [1] "2.2"
class(num_char)
## [1] "character"

# coerce character to numeric!
class(char)
## [1] "character"
char_num <- as.numeric(char)
## Warning: NAs introduced by coercion