#install.packages("ggplot2")
library(ggplot2)


##------------------------------ Basic ggplot --------------------------

ggplot()

flower <- read.table("data/flower.txt", stringsAsFactors = TRUE, 
                     header = TRUE, sep = "\t")
str(flower)
## 'data.frame':    96 obs. of  8 variables:
##  $ treat    : Factor w/ 2 levels "notip","tip": 2 2 2 2 2 2 2 2 2 2 ...
##  $ nitrogen : Factor w/ 3 levels "high","low","medium": 3 3 3 3 3 3 3 3 3 3 ...
##  $ block    : int  1 1 1 1 1 1 1 1 2 2 ...
##  $ height   : num  7.5 10.7 11.2 10.4 10.4 9.8 6.9 9.4 10.4 12.3 ...
##  $ weight   : num  7.62 12.14 12.76 8.78 13.58 ...
##  $ leafarea : num  11.7 14.1 7.1 11.9 14.5 12.2 13.2 14 10.5 16.1 ...
##  $ shootarea: num  31.9 46 66.7 20.3 26.9 72.7 43.1 28.5 57.8 36.9 ...
##  $ flowers  : int  1 10 10 1 4 9 7 6 5 8 ...

# Including aesthetics for x and y axes as well as specifying the dataset
ggplot(mapping = aes(x = weight, y = shootarea), data = flower)

# Add anew layer
ggplot(aes(x = weight, y = shootarea), data = flower) +
  geom_point()     # Adding a geom to display data as point data

ggplot(aes(x = weight, y = shootarea), data = flower) +
  geom_point(color="red") +
  geom_line()     # Adding geom_line

ggplot(aes(x = weight, y = shootarea), data = flower) +
  geom_point() +
  geom_smooth()    # Changing to geom_smooth

ggplot(aes(x = weight, y = shootarea), data = flower) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE)    # method and se 

ggplot(aes(x = weight, y = shootarea), data = flower) +
  geom_point() +
  # Including colour argument in aes()
  geom_smooth(aes(colour = nitrogen), method = "lm", se = FALSE)

# same thing as the previous function
ggplot() +
  # Moved aes() and data into geoms
  geom_point(aes(x = weight, y = shootarea), data = flower) +
  geom_smooth(aes(x = weight, y = shootarea, colour = nitrogen), 
              data = flower, method = "lm", se = FALSE)


# Moved colour = nitrogen into the universal ggplot()
ggplot(aes(x = weight, y = shootarea, colour = nitrogen), data = flower) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE)


##------------------------------ Wrapping Grids --------------------------

ggplot(aes(x = weight, y = shootarea, colour = nitrogen), data = flower) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +
  # Splitting the single figure into multiple depending on treatment
  facet_wrap(~ treat)

ggplot(aes(x = weight, y = shootarea, colour = nitrogen), data = flower) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +
  # Splitting the single figure into multiple depending on treatment
  facet_wrap(~ treat + block)

