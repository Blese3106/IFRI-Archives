help("mean")
?mean

help.search("mean")
??mean

apropos("mean")
##  [1] ".colMeans"     ".rowMeans"     "colMeans"      "kmeans"       
##  [5] "mean"          "mean_temp"     "mean.Date"     "mean.default" 
##  [9] "mean.difftime" "mean.POSIXct"  "mean.POSIXlt"  "rowMeans"     
## [13] "vec_mean"      "weighted.mean"


#RSiteSearch("regression")
