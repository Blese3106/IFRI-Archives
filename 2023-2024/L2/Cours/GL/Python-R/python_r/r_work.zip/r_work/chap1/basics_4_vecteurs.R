my_vec <- c(2, 3, 1, 6, 4, 3, 3, 7)
my_vec        # remind ourselves what my_vec looks like
## [1] 2 3 1 6 4 3 3 7


# ----------- Extracting elements ---------------
my_vec[3]     # extract the 3rd value
## [1] 1
# if you want to store this value in another object
val_3 <- my_vec[3]
val_3
## [1] 1

my_vec[c(1, 5, 6, 8)]
## [1] 2 4 3 7
my_vec[3:8]
## [1] 1 6 4 3 3 7

my_vec[my_vec > 4]
## [1] 6 7
my_vec > 4
## [1] FALSE FALSE FALSE  TRUE FALSE FALSE FALSE  TRUE
my_vec[c(FALSE, FALSE, FALSE, TRUE, FALSE, FALSE, FALSE, TRUE)]
## [1] 6 7

my_vec[my_vec >= 4]        # values greater or equal to 4
## [1] 6 4 7
my_vec[my_vec < 4]         # values less than 4
## [1] 2 3 1 3 3
my_vec[my_vec <= 4]        # values less than or equal to 4
## [1] 2 3 1 4 3 3
my_vec[my_vec == 4]        # values equal to 4
## [1] 4
my_vec[my_vec != 4]        # values not equal to 4
## [1] 2 3 1 6 3 3 7

val26 <- my_vec[my_vec < 6 & my_vec > 2]
val26
## [1] 3 4 3 3
val63 <- my_vec[my_vec > 6 | my_vec < 3]
val63
## [1] 2 1 7


# ----------- Replacing elements ---------------
my_vec[4] <- 500
my_vec
## [1]   2   3   1 500   4   3   3   7

# replace the 6th and 7th element with 100
my_vec[c(6, 7)] <- 100
my_vec
## [1]   2   3   1 500   4 100 100   7

# replace element that are less than or equal to 4 with 1000
my_vec[my_vec <= 4] <- 1000
my_vec
## [1] 1000 1000 1000  500 1000  100  100    7

# ----------- Ordering elements ---------------
vec_sort <- sort(my_vec)
vec_sort
## [1]    7  100  100  500 1000 1000 1000 1000
vec_sort2 <- sort(my_vec, decreasing = TRUE)
vec_sort2
## [1] 1000 1000 1000 1000  500  100  100    7
vec_sort3 <- rev(sort(my_vec))
vec_sort3
## [1] 1000 1000 1000 1000  500  100  100    7

height <- c(180, 155, 160, 167, 181)
height
## [1] 180 155 160 167 181
p.names <- c("Joanna", "Charlotte", "Helen", "Karen", "Amy")
p.names
## [1] "Joanna"    "Charlotte" "Helen"     "Karen"     "Amy"

height_ord <- order(height)
height_ord
## [1] 2 3 4 1 5
names_ord <- p.names[height_ord]
names_ord
## [1] "Charlotte" "Helen"     "Karen"     "Joanna"    "Amy"


# ----------- Vectorisation ---------------
# create a vector
my_vec2 <- c(3, 5, 7, 1, 9, 20)
# multiply each element by 5
my_vec2 * 5
## [1]  15  25  35   5  45 100


# create a second vector
my_vec3 <- c(17, 15, 13, 19, 11, 0)
# add both vectors
my_vec2 + my_vec3
## [1] 20 20 20 20 20 20
# multiply both vectors
my_vec2 * my_vec3
## [1] 51 75 91 19 99  0


# create a third vector
my_vec4 <- c(1, 2)
# add both vectors - quiet recycling!
my_vec2 + my_vec4
## [1]  4  7  8  3 10 22


# ----------- Missing data ---------------
temp  <- c(7.2, NA, 7.1, 6.9, 6.5, 5.8, 5.8, 5.5, NA, 5.5)
temp
##  [1] 7.2  NA 7.1 6.9 6.5 5.8 5.8 5.5  NA 5.5
mean_temp <- mean(temp)
mean_temp
## [1] NA
mean_temp <- mean(temp, na.rm = TRUE)
mean_temp
## [1] 6.2875





