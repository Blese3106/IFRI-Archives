# creer un objet
my_obj <- 48
my_obj
## [1] 48

my_obj2 <- "R is cool"
my_obj2 <- 1024

my_obj3 <- my_obj + my_obj2
my_obj3
## [1] 1072

char_obj <- "hello"
char_obj2 <- "world!"
char_obj3 <- char_obj + char_obj2
## Error in char_obj+char_obj2:non-numeric argument to binary operator


my_obj <- 48
my_obj4 <- my_obj + no_obj
## Error: object 'no_obj' not found

#data <- read.table("mydatafile", header = TRUE) 
#data est une fonction native en R et ne devrait pas etre utilise comme nom d'objet!


